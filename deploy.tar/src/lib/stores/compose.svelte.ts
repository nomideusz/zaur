import { browser } from '$app/environment';
import type { JMAPClient } from '$lib/jmap/client';
import type { EmailAttachmentInput } from '$lib/jmap/email-build';
import { validateAttachmentFile } from '$lib/attachments/upload';
import { parseAddressList } from '$lib/utils/addresses';
import { isOfflineError } from '$lib/utils/network';
import { outbox } from '$lib/stores/outbox.svelte';
import { settings } from '$lib/stores/settings.svelte';
import { toast } from '$lib/stores/toast.svelte';
import type { ComposeAttachment, StoredComposeAttachment } from '$lib/types/compose';
import type { MessageDetail } from '$lib/types/mail';

export type ComposeMode = 'new' | 'reply' | 'reply-all' | 'forward';
export type ComposeSendResult = 'sent' | 'queued' | false;

const AUTOSAVE_MS = 2000;
const SERVER_DRAFT_MS = 5000;

function quoteHeader(message: MessageDetail) {
	const when = new Intl.DateTimeFormat(undefined, {
		dateStyle: 'medium',
		timeStyle: 'short'
	}).format(new Date(message.receivedAt));

	const toLine = message.to.map((addr) => addr.name || addr.email).join(', ');
	return `From: ${message.from.name} <${message.from.email}>\nDate: ${when}\nSubject: ${message.subject}\nTo: ${toLine}`;
}

class ComposeStore {
	to = $state('');
	cc = $state('');
	bcc = $state('');
	subject = $state('');
	body = $state('');
	showCcBcc = $state(false);
	mode = $state<ComposeMode>('new');
	jmapDraftId = $state<string | undefined>(undefined);
	isSending = $state(false);
	isSavingDraft = $state(false);
	draftSavedAt = $state<number | null>(null);
	error = $state<string | null>(null);
	attachments = $state<ComposeAttachment[]>([]);

	private autosaveTimer: ReturnType<typeof setTimeout> | null = null;
	private serverDraftTimer: ReturnType<typeof setTimeout> | null = null;

	get hasUploadingAttachments() {
		return this.attachments.some((attachment) => attachment.uploading);
	}

	get canSend() {
		return (
			!this.isSending &&
			!this.hasUploadingAttachments &&
			parseAddressList(this.to).length > 0
		);
	}

	startNew() {
		void this.restoreLocalDraft();
	}

	private async restoreLocalDraft() {
		if (!browser) return;

		const { getAccountId, getComposeDraft } = await import('$lib/db');
		const accountId = getAccountId();
		if (!accountId) {
			this.resetComposeFields();
			return;
		}

		const draft = await getComposeDraft(accountId);
		if (!draft) {
			this.resetComposeFields();
			return;
		}

		this.to = draft.to;
		this.cc = draft.cc;
		this.bcc = draft.bcc;
		this.subject = draft.subject;
		this.body = draft.body;
		this.jmapDraftId = draft.jmapDraftId;
		this.showCcBcc = !!(draft.cc || draft.bcc);
		this.mode = draft.mode;
		this.draftSavedAt = draft.updatedAt;
		this.error = null;
		this.attachments = (draft.attachments ?? []).map((attachment) => ({
			id: crypto.randomUUID(),
			name: attachment.name,
			type: attachment.type,
			size: attachment.size,
			blobId: attachment.blobId,
			uploading: false
		}));
	}

	private clearAttachments() {
		this.attachments = [];
	}

	private importMessageAttachments(message: MessageDetail) {
		this.attachments = message.attachments.map((attachment) => ({
			id: crypto.randomUUID(),
			name: attachment.name,
			type: attachment.type,
			size: attachment.size,
			blobId: attachment.blobId,
			uploading: false
		}));
	}

	private resetComposeFields() {
		this.to = '';
		this.cc = '';
		this.bcc = '';
		this.subject = '';
		this.body = settings.composeBodyWithSignature();
		this.showCcBcc = false;
		this.mode = 'new';
		this.jmapDraftId = undefined;
		this.error = null;
		this.draftSavedAt = null;
		this.clearAttachments();
	}

	private storedAttachments(): StoredComposeAttachment[] {
		return this.attachments
			.filter((attachment): attachment is ComposeAttachment & { blobId: string } => !!attachment.blobId)
			.map((attachment) => ({
				name: attachment.name,
				type: attachment.type,
				size: attachment.size,
				blobId: attachment.blobId
			}));
	}

	private readyAttachments(): EmailAttachmentInput[] {
		return this.storedAttachments();
	}

	async addAttachments(client: JMAPClient, files: FileList | File[]) {
		if (!browser) return;
		if (!navigator.onLine) {
			toast.show('Connect to the internet to attach files', 'error');
			return;
		}

		for (const file of files) {
			const validationError = validateAttachmentFile(file, this.attachments.length);
			if (validationError) {
				toast.show(validationError, 'error');
				continue;
			}

			const id = crypto.randomUUID();
			this.attachments = [
				...this.attachments,
				{
					id,
					name: file.name,
					type: file.type || 'application/octet-stream',
					size: file.size,
					blobId: null,
					uploading: true
				}
			];

			try {
				const uploaded = await client.uploadBlob(file, file.type || 'application/octet-stream');
				this.attachments = this.attachments.map((attachment) =>
					attachment.id === id
						? { ...attachment, blobId: uploaded.blobId, uploading: false, uploadError: undefined }
						: attachment
				);
			} catch (error) {
				const message = error instanceof Error ? error.message : 'Upload failed';
				this.attachments = this.attachments.map((attachment) =>
					attachment.id === id
						? { ...attachment, uploading: false, uploadError: message }
						: attachment
				);
				toast.show(`Could not attach "${file.name}" — ${message}`, 'error');
			}
		}
	}

	removeAttachment(id: string) {
		this.attachments = this.attachments.filter((attachment) => attachment.id !== id);
	}

	startReply(message: MessageDetail) {
		const when = new Intl.DateTimeFormat(undefined, {
			dateStyle: 'medium',
			timeStyle: 'short'
		}).format(new Date(message.receivedAt));

		this.mode = 'reply';
		this.to = message.from.email;
		this.cc = '';
		this.bcc = '';
		this.showCcBcc = false;
		this.subject = message.subject.startsWith('Re:') ? message.subject : `Re: ${message.subject}`;
		this.body = settings.composeBodyWithSignature(
			`\n\n---\nOn ${when}, ${message.from.name} wrote:\n${message.bodyText}`
		);
		this.jmapDraftId = undefined;
		this.error = null;
		this.draftSavedAt = null;
		this.clearAttachments();
	}

	startReplyAll(message: MessageDetail, thread: MessageDetail[], userEmail: string) {
		const normalizedUser = userEmail.trim().toLowerCase();
		const recipients = new Set<string>();

		for (const item of thread) {
			if (item.from.email.toLowerCase() !== normalizedUser) {
				recipients.add(item.from.email);
			}
			for (const addr of item.to) {
				if (addr.email.toLowerCase() !== normalizedUser) {
					recipients.add(addr.email);
				}
			}
			for (const addr of item.cc) {
				if (addr.email.toLowerCase() !== normalizedUser) {
					recipients.add(addr.email);
				}
			}
		}

		const when = new Intl.DateTimeFormat(undefined, {
			dateStyle: 'medium',
			timeStyle: 'short'
		}).format(new Date(message.receivedAt));

		this.mode = 'reply-all';
		this.to = Array.from(recipients).join(', ');
		this.cc = '';
		this.bcc = '';
		this.showCcBcc = false;
		this.subject = message.subject.startsWith('Re:') ? message.subject : `Re: ${message.subject}`;
		this.body = settings.composeBodyWithSignature(
			`\n\n---\nOn ${when}, ${message.from.name} wrote:\n${message.bodyText}`
		);
		this.jmapDraftId = undefined;
		this.error = null;
		this.draftSavedAt = null;
		this.clearAttachments();
	}

	startForward(message: MessageDetail) {
		this.mode = 'forward';
		this.to = '';
		this.cc = '';
		this.bcc = '';
		this.showCcBcc = false;
		this.subject = message.subject.startsWith('Fwd:') ? message.subject : `Fwd: ${message.subject}`;
		this.body = settings.composeBodyWithSignature(
			`\n\n---\nForwarded message:\n${quoteHeader(message)}\n\n${message.bodyText}`
		);
		this.jmapDraftId = undefined;
		this.error = null;
		this.draftSavedAt = null;
		this.importMessageAttachments(message);
		void this.persistLocalDraft();
	}

	scheduleAutosave(client: JMAPClient | null, fromEmail: string, fromName?: string) {
		if (!browser) return;

		if (this.autosaveTimer) clearTimeout(this.autosaveTimer);
		this.autosaveTimer = setTimeout(() => {
			void this.persistLocalDraft();
		}, AUTOSAVE_MS);

		if (!client || this.mode !== 'new') return;

		if (this.serverDraftTimer) clearTimeout(this.serverDraftTimer);
		this.serverDraftTimer = setTimeout(() => {
			void this.saveServerDraft(client, fromEmail, fromName);
		}, SERVER_DRAFT_MS);
	}

	reset() {
		if (this.autosaveTimer) clearTimeout(this.autosaveTimer);
		if (this.serverDraftTimer) clearTimeout(this.serverDraftTimer);
		void this.clearLocalDraft();
		this.to = '';
		this.cc = '';
		this.bcc = '';
		this.subject = '';
		this.body = '';
		this.showCcBcc = false;
		this.mode = 'new';
		this.jmapDraftId = undefined;
		this.isSending = false;
		this.isSavingDraft = false;
		this.draftSavedAt = null;
		this.error = null;
		this.clearAttachments();
	}

	async send(client: JMAPClient, fromEmail: string, fromName?: string): Promise<ComposeSendResult> {
		const recipients = parseAddressList(this.to);
		if (!recipients.length) {
			this.error = 'Enter at least one recipient';
			return false;
		}
		if (this.hasUploadingAttachments) {
			this.error = 'Wait for attachments to finish uploading';
			return false;
		}

		const failedAttachment = this.attachments.find((attachment) => attachment.uploadError);
		if (failedAttachment) {
			this.error = `Remove or re-attach "${failedAttachment.name}" before sending`;
			return false;
		}

		this.isSending = true;
		this.error = null;

		const cc = parseAddressList(this.cc);
		const bcc = parseAddressList(this.bcc);
		const draftId = this.jmapDraftId;
		const attachments = this.readyAttachments();
		const subject = this.subject.trim() || '(no subject)';
		const sendOptions = {
			fromEmail,
			fromName: fromName?.trim() || undefined,
			cc: cc.length ? cc : undefined,
			bcc: bcc.length ? bcc : undefined,
			attachments: attachments.length ? attachments : undefined,
			format: settings.defaultComposeFormat
		};

		try {
			await client.sendEmail(recipients, subject, this.body, sendOptions);

			if (draftId) {
				try {
					await client.destroyEmail(draftId);
				} catch {
					// Draft cleanup is best-effort
				}
			}

			this.reset();
			return 'sent';
		} catch (error) {
			if (browser && isOfflineError(error)) {
				const { getAccountId, enqueueOutbox } = await import('$lib/db');
				const accountId = getAccountId();
				if (accountId) {
					const subject = this.subject.trim() || '(no subject)';
					await enqueueOutbox(accountId, {
						to: this.to,
						cc: this.cc,
						bcc: this.bcc,
						subject,
						body: this.body,
						fromEmail,
						fromName: fromName?.trim() || undefined,
						attachments: attachments.length ? attachments : undefined
					});
					void import('$lib/sync/outbox-processor').then(({ outboxProcessor }) =>
						outboxProcessor.processQueue()
					);
					void outbox.refresh();
					this.reset();
					toast.show(`"${subject}" queued — will send when back online`, 'info');
					return 'queued';
				}
			}

			const message = error instanceof Error ? error.message : 'Failed to send message';
			this.error = message;
			toast.show(message, 'error');
			return false;
		} finally {
			this.isSending = false;
		}
	}

	private async persistLocalDraft() {
		if (!browser) return;
		if (this.mode !== 'new' && !this.attachments.length) return;
		if (!this.to && !this.cc && !this.bcc && !this.subject && !this.body && !this.attachments.length) {
			await this.clearLocalDraft();
			return;
		}

		const { getAccountId, saveComposeDraft } = await import('$lib/db');
		const accountId = getAccountId();
		if (!accountId) return;

		const updatedAt = Date.now();
		const storedAttachments = this.storedAttachments();
		await saveComposeDraft(accountId, {
			to: this.to,
			cc: this.cc,
			bcc: this.bcc,
			subject: this.subject,
			body: this.body,
			mode: this.mode,
			jmapDraftId: this.jmapDraftId,
			attachments: storedAttachments.length ? storedAttachments : undefined,
			updatedAt
		});
		this.draftSavedAt = updatedAt;
	}

	private async clearLocalDraft() {
		if (!browser) return;
		const { getAccountId, clearComposeDraft } = await import('$lib/db');
		const accountId = getAccountId();
		if (!accountId) return;
		await clearComposeDraft(accountId);
	}

	private async saveServerDraft(client: JMAPClient, fromEmail: string, fromName?: string) {
		if (!this.to && !this.subject && !this.body) return;

		this.isSavingDraft = true;
		try {
			const id = await client.saveDraft({
				jmapDraftId: this.jmapDraftId,
				to: parseAddressList(this.to),
				cc: parseAddressList(this.cc),
				bcc: parseAddressList(this.bcc),
				subject: this.subject.trim(),
				body: this.body,
				fromEmail,
				fromName: fromName?.trim() || undefined,
				attachments: this.readyAttachments(),
				format: settings.defaultComposeFormat
			});
			this.jmapDraftId = id;
			this.draftSavedAt = Date.now();
			void this.persistLocalDraft();
		} catch {
			// Server draft save is best-effort
		} finally {
			this.isSavingDraft = false;
		}
	}
}

export const compose = new ComposeStore();
