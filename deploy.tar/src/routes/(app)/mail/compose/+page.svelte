<script lang="ts">
	import { afterNavigate } from '$app/navigation';
	import { page } from '$app/stores';
	import ComposePanel from '$lib/components/mail/ComposePanel.svelte';
	import MailboxSidebar from '$lib/components/mail/MailboxSidebar.svelte';
	import { compose, type ComposeMode } from '$lib/stores/compose.svelte';
	import { settings } from '$lib/stores/settings.svelte';

	const COMPOSE_MODES = new Set<ComposeMode>(['new', 'reply', 'reply-all', 'forward']);

	const mode = $derived.by(() => {
		const value = $page.url.searchParams.get('mode');
		return value && COMPOSE_MODES.has(value as ComposeMode) ? (value as ComposeMode) : 'new';
	});

	const initialTo = $derived($page.url.searchParams.get('to') ?? '');

	afterNavigate(({ from, to }) => {
		if (to?.url.pathname !== '/mail/compose') return;
		const toMode = to.url.searchParams.get('mode');
		if (toMode && toMode !== 'new') return;
		if (from?.url.pathname === '/mail/compose') return;
		compose.startNew();
	});
</script>

<svelte:head>
	<title>Compose · ZAUR Webmail</title>
</svelte:head>

{#if settings.composeLayout === 'pane'}
	<MailboxSidebar />
{/if}

<ComposePanel {mode} {initialTo} />
