<script lang="ts">
	import { goto } from '$app/navigation';
	import MailPane from '$lib/components/mail/MailPane.svelte';
	import MessageList from '$lib/components/mail/MessageList.svelte';
	import MessageReader from '$lib/components/mail/MessageReader.svelte';
	import MessageReaderSkeleton from '$lib/components/mail/MessageReaderSkeleton.svelte';
	import MessageReaderStatus from '$lib/components/mail/MessageReaderStatus.svelte';
	import { mailCountLabel } from '$lib/mail/count-label';
	import { auth } from '$lib/stores/auth.svelte';
	import { mail } from '$lib/stores/mail.svelte';

	const { data } = $props();

	const mailbox = $derived(mail.mailboxByRouteId(data.mailboxId));
	const mailboxName = $derived(mailbox?.name ?? 'Inbox');
	const thread = $derived(mail.selectedThread);
	const latest = $derived(thread.at(-1));
	const countLabel = $derived(
		mailCountLabel(mail.messagesTotal, mail.messages.length, mailbox)
	);

	function backToList() {
		goto(`/mail/${data.mailboxId}`);
	}

	function afterMove() {
		backToList();
	}

	$effect(() => {
		const client = auth.client;
		if (!client || auth.isRestoring) return;
		void mail.loadMessage(client, data.mailboxId, data.threadId);
	});
</script>

<svelte:head>
	<title>{latest?.subject ?? mailboxName} · ZAUR Webmail</title>
</svelte:head>

<MailPane
	{mailboxName}
	{countLabel}
	mailboxRouteId={data.mailboxId}
	loading={mail.messagesLoading}
	error={mail.messagesError}
	messageCount={mail.messages.length}
	onBulkAction={afterMove}
	onBack={backToList}
	fullScreenMobile
>
	{#snippet list()}
		<MessageList
			messages={mail.messages}
			{mailboxName}
			mailboxRouteId={data.mailboxId}
			hideOnMobile
			loading={mail.messagesLoading}
			loadingMore={mail.messagesLoadingMore}
			hasMore={mail.messagesHasMore}
			error={mail.messagesError}
			total={mail.messagesTotal}
			onLoadMore={() => {
				if (auth.client) void mail.loadMoreMessages(auth.client);
			}}
			onRetry={() => {
				if (auth.client) void mail.loadMessages(auth.client, data.mailboxId);
			}}
		/>
	{/snippet}
	{#snippet reader()}
		{#if mail.selectedLoading}
			<div class="z-mail-reader-pane">
				<MessageReaderSkeleton />
			</div>
		{:else if thread.length}
			<div class="z-mail-reader-pane">
				<MessageReader {thread} mailboxRouteId={data.mailboxId} />
			</div>
		{:else}
			<div class="z-mail-reader-pane">
				<MessageReaderStatus
					message={mail.selectedError ?? 'Message not found.'}
					onBack={backToList}
				/>
			</div>
		{/if}
	{/snippet}
</MailPane>
