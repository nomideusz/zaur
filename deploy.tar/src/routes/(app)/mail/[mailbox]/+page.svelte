<script lang="ts">
	import MailPane from '$lib/components/mail/MailPane.svelte';
	import MessageList from '$lib/components/mail/MessageList.svelte';
	import MessageReaderEmpty from '$lib/components/mail/MessageReaderEmpty.svelte';
	import { mailCountLabel } from '$lib/mail/count-label';
	import { auth } from '$lib/stores/auth.svelte';
	import { mail } from '$lib/stores/mail.svelte';
	import { settings } from '$lib/stores/settings.svelte';

	const { data } = $props();

	const mailbox = $derived(mail.mailboxByRouteId(data.mailboxId));
	const mailboxName = $derived(mailbox?.name ?? 'Inbox');
	const countLabel = $derived(
		mailCountLabel(mail.messagesTotal, mail.messages.length, mailbox)
	);

	$effect(() => {
		const client = auth.client;
		if (!client || auth.isRestoring) return;
		void mail.loadMessages(client, data.mailboxId);
	});

	$effect(() => {
		settings.setLastMailbox(data.mailboxId);
	});
</script>

<svelte:head>
	<title>{mailboxName} · ZAUR Webmail</title>
</svelte:head>

<MailPane
	{mailboxName}
	{countLabel}
	mailboxRouteId={data.mailboxId}
	loading={mail.messagesLoading}
	error={mail.messagesError}
	messageCount={mail.messages.length}
>
	{#snippet list()}
		<MessageList
			messages={mail.messages}
			{mailboxName}
			mailboxRouteId={data.mailboxId}
			expanded={settings.expandListUntilOpen}
			loading={mail.messagesLoading}
			loadingMore={mail.messagesLoadingMore}
			hasMore={mail.messagesHasMore}
			error={mail.messagesError}
			total={mail.messagesTotal}
			onLoadMore={() => {
				if (auth.client) void mail.loadMoreMessages(auth.client);
			}}
			onRetry={() => {
				if (auth.client) void mail.loadMessages(auth.client, data.mailboxId);
			}}
		/>
	{/snippet}
	{#snippet reader()}
		{#if !settings.expandListUntilOpen}
			<div class="z-mail-reader-pane">
				<MessageReaderEmpty />
			</div>
		{/if}
	{/snippet}
</MailPane>
